<?php 
$route[FUEL_ROUTE.'speakers'] = 'speakers';