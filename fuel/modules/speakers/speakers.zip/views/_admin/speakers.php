<div id="fuel_main_content_inner">
	<p class="instructions">This view is located in the fuel/modules/speakers/views/_admin/ folder.</p>
</div>