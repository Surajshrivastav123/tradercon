<?php 

$config['modules']['speakers_master'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'speakers', // put in the advanced module name here
);
