<?php 

$config['modules']['sponsors_master'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'sponsors', // put in the advanced module name here
);

$config['modules']['category_master'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'sponsors', // put in the advanced module name here
);
