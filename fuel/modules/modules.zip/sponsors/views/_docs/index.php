<h1>Sponsors Module Documentation</h1>
<p>This Sponsors module documentation is for version <?=SPONSORS_VERSION?>.</p>

<?=generate_config_info()?>

<?=generate_toc()?>