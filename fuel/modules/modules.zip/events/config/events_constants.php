<?php 
define('EVENTS_VERSION', '1.0');
define('EVENTS_FOLDER', 'events');
define('EVENTS_PATH', MODULES_PATH.EVENTS_FOLDER.'/');