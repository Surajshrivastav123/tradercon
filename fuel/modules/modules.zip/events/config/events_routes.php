<?php 
$route[FUEL_ROUTE.'events'] = 'events';