<?php
/*
|--------------------------------------------------------------------------
| FUEL NAVIGATION: An array of navigation items for the left menu
|--------------------------------------------------------------------------
*/
$config['nav']['events'] = array(
		'events_master' => 'Events',
		'event_sponsors' => 'Event Sponsors',
		'event_speakers' => 'Event Speakers',
		'event_images' => 'Event Images',
		'event_videos' => 'Event Videos',
		'event_pricing_plans' => 'Event Pricing Plan',
	);


/*
|--------------------------------------------------------------------------
| ADDITIONAL SETTINGS:
|--------------------------------------------------------------------------
*/
