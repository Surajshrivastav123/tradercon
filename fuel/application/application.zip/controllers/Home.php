<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of home
 *
 * @author swarnasekhar.dhar
 */
class home  extends CI_Controller 
{
    private $event_type=array();
     public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('my_helper'));
        
        error_reporting(E_ALL);
        @ini_set('display_errors', 1);
	ini_set('error_reporting', E_ALL);
      //  $procidu=   $this->uri->segment(2) ;
      // if($procidu != ''){if(!method_exists($this,$procidu)) { redirect(base_url('404'));  }}
        
    }
	
    function index()
    {
        $vars=array();
        $vars['layout'] = 'home';
        $vars['page_title'] = 'Home';
        $vars['body_class'] = 'home';
     
        $this->fuel->pages->render('home', $vars);

    }

    function speakers()
    {
        $vars=array();
        $vars['layout'] = 'speakers';
        $vars['page_title'] = 'Event Speakers';
        $vars['body_class'] = 'Event Speakers';
        $vars['speakers_list'] = $this->db->select('c.*')
        ->from('event_speakers as es')
        ->join('events_master as b', 'b.id=es.event_id', 'left')
        ->join('speakers_master as c', 'c.id=es.speaker_id', 'left')
        ->where(array(
          'b.published'=>'yes',
    
          'es.published'=>'yes'
        ))->get()->result();
      //  echo $this->db->last_query( );
        $this->fuel->pages->render('blank', $vars);

    }
    function profile($id)
    {
      
        $vars=array();
        $vars['layout'] = 'profile';
        $vars['page_title'] = 'Event Speakers';
        $vars['body_class'] = 'Event Speakers';
        $vars['speaker'] = $this->db->select('*')
        ->from('speakers_master')
        ->where(array(
           
    
          'id'=> $id
        ))->get()->row();
        $this->fuel->pages->render('blank', $vars);

    }

    function sponsors()
    {
        $vars=array();
        $vars['layout'] = 'sponsors';
        $vars['page_title'] = 'Event Speakers';
        $vars['body_class'] = 'Event Speakers';
        $vars['speakers_list'] = $this->db->select('c.*')
        ->from('event_speakers as es')
        ->join('events_master as b', 'b.id=es.event_id', 'left')
        ->join('speakers_master as c', 'c.id=es.speaker_id', 'left')
        ->where(array(
          'b.published'=>'yes',
    
          'es.published'=>'yes'
        ))->get()->result();
      //  echo $this->db->last_query( );
        $this->fuel->pages->render('blank', $vars);

    }
}