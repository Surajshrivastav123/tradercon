 <!--================= Wrapper Start Here =================-->
<div class="react-wrapper">
  <div class="react-wrapper-inner"> 
    
    <!--================= Slider Section Start Here =================-->
    <div class="react-slider-part">
      <section class="banner">
        <div class="banner-inner">
          <h1>ESPRESSO TRADERS<br>
            CARNIVAL 18th Edition</h1>
          <h4>EVENT WILL START IN</h4>
          <div id="normal-countdown" data-date="2022/02/02"></div>
          <a href="#" class="buybtn"> Buy Ticket Now
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right">
            <line x1="5" y1="12" x2="19" y2="12"></line>
            <polyline points="12 5 19 12 12 19"></polyline>
          </svg>
          </a> </div>
      </section>
    </div>
    <!--================= Slider Section End Here =================--> 
    
    <!--=================  About Section Start Here ================= -->
    <div class="about__area about__area_one p-relative pt---100 pb---70">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="about__content">
              <h2 class="about__title">Welcome to <br>
                <em>A Decade Of Excellence</em></h2>
              <p class="about__paragraph">It all began on a cold winter morning on 26th October 2012 at Bangalore. History was made with the successful launch of the very first Edition of Traders Carnival.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--================= About Section End Here ================= --> 
    
    <!--================= Upcoming Event Section Start Here =================-->
    <div class="react-upcoming__event blog__area pb---100">
      <div class="container">
        <div class="react__title__section text-center">
          <h5>Listen to the </h5>
          <h2 class="react__tittle">Event Speakers</h2>
        </div>
        <div class="instructors___page">
          <div class="row">
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/1.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/2.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/3.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/4.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/5.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/6.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/7.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/8.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/9.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="instructor__content">
                <div class="instructor__image"> <img src="assets/images/instructors/10.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Douglas Lyphe</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="profile.html"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Douglas Lyphe</a></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--================= Upcoming Event Section End Here =================--> 
  
  <!--=================  Pricing Start Here  =================-->
  <div class="pricing-section home-five pt---120">
    <div class="pricing-section-header-bg"></div>
    <div class="container">
      <div class="section-title-area home-five text-center">
        <div class="section-pretitle">I’M OFFER 3 UNIQUE PRICING PLANS</div>
        <div class="section-title">Pricing & Offerings Plan </div>
      </div>
      <div class="row justify-content-center">
        <div class="col-xl-4 col-md-4">
          <div class="price-card">
            <div class="price-plan">
              <div class="contents shape1 circle1">
                <div class="plan-type">2 Nights 3 Days Conference + Live Monthly Expiry Day Trading</div>
                <div class="price shapeTwo shapethree">3 Days - Double Occupancy</div>
              </div>
            </div>
            <div class="price-details">
              <div class="item"> <i class="icon_check_alt2"></i>Conference + Live Expiry Day Trading </div>
              <div class="item"><i class="icon_check_alt2"></i>Accommodation for 2 nights and 3 days at The Leela Ambience Convention Hotel, Delhi on DOUBLE OCCUPANCY from 16 to 18 November 2022 </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all strategy and networking sessions during the 3 day event. </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to Expiry Day Trading - LIVE! </div>
              <div class="item"><i class="icon_check_alt2"></i>All meals during the conference, Coffee, Tea, Snacks, beverages </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary Internet access during the Conference. Internet connectivity of two devices per person is available. </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary access to indoor and out door activities, Club House and Pool </div>
              <div class="item"><i class="icon_check_alt2"></i> Swag-Conference Merch - Backpacks, Tshirts </div>
              <div class="item"><i class="icon_check_alt2"></i>Special offer from Partners plus Merch++ </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all recordings of all 3 days </div>
              <button class="price-btn">
              <a href="coureses-single.html">BOOK NOW</a>
              </button>
            </div>
          </div>
        </div>
        <div class="col-xl-4 col-md-4">
          <div class="price-card">
            <div class="price-plan">
              <div class="contents shape1 circle1">
                <div class="plan-type">2 Nights 3 Days Conference + Live Monthly Expiry Day Trading</div>
                <div class="price shapeTwo shapethree">3 Days - Double Occupancy</div>
              </div>
            </div>
            <div class="price-details">
              <div class="item"> <i class="icon_check_alt2"></i>Conference + Live Expiry Day Trading </div>
              <div class="item"><i class="icon_check_alt2"></i>Accommodation for 2 nights and 3 days at The Leela Ambience Convention Hotel, Delhi on DOUBLE OCCUPANCY from 16 to 18 November 2022 </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all strategy and networking sessions during the 3 day event. </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to Expiry Day Trading - LIVE! </div>
              <div class="item"><i class="icon_check_alt2"></i>All meals during the conference, Coffee, Tea, Snacks, beverages </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary Internet access during the Conference. Internet connectivity of two devices per person is available. </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary access to indoor and out door activities, Club House and Pool </div>
              <div class="item"><i class="icon_check_alt2"></i> Swag-Conference Merch - Backpacks, Tshirts </div>
              <div class="item"><i class="icon_check_alt2"></i>Special offer from Partners plus Merch++ </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all recordings of all 3 days </div>
              <button class="price-btn">
              <a href="coureses-single.html">BOOK NOW</a>
              </button>
            </div>
          </div>
        </div>
        <div class="col-xl-4 col-md-4">
          <div class="price-card">
            <div class="price-plan">
              <div class="contents shape1 circle1">
                <div class="plan-type">2 Nights 3 Days Conference + Live Monthly Expiry Day Trading</div>
                <div class="price shapeTwo shapethree">3 Days - Double Occupancy</div>
              </div>
            </div>
            <div class="price-details">
              <div class="item"> <i class="icon_check_alt2"></i>Conference + Live Expiry Day Trading </div>
              <div class="item"><i class="icon_check_alt2"></i>Accommodation for 2 nights and 3 days at The Leela Ambience Convention Hotel, Delhi on DOUBLE OCCUPANCY from 16 to 18 November 2022 </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all strategy and networking sessions during the 3 day event. </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to Expiry Day Trading - LIVE! </div>
              <div class="item"><i class="icon_check_alt2"></i>All meals during the conference, Coffee, Tea, Snacks, beverages </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary Internet access during the Conference. Internet connectivity of two devices per person is available. </div>
              <div class="item"><i class="icon_check_alt2"></i>Complimentary access to indoor and out door activities, Club House and Pool </div>
              <div class="item"><i class="icon_check_alt2"></i> Swag-Conference Merch - Backpacks, Tshirts </div>
              <div class="item"><i class="icon_check_alt2"></i>Special offer from Partners plus Merch++ </div>
              <div class="item"><i class="icon_check_alt2"></i>Access to all recordings of all 3 days </div>
              <button class="price-btn">
              <a href="coureses-single.html">BOOK NOW</a>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--=================  Pricing End Here  =================--> 
  
  <!--================= Clients Section Start Here =================-->
  <div class="react-clients react-clientso pt---120 pb---120 mt---102">
    <div class="container">
      <div class="react__title__section text-center">
        <h6 class="react__subtitle">Graat Words About carnival.</h6>
        <h2 class="react__tittle"> What our clients say about </h2>
      </div>
      <div class="container">
        <div class="client-slider owl-carousel">
          <div class="single-client">
            <div class="client-bottom"> <span class="client-author"><img src="assets/images/testimonial/testimonial.png" alt="Testimonials"> </span> </div>
            <div class="client-content"> <span class="client-title">Justin Case <em> Student</em></span>
              <p>Nulla porttitor accumsan tincidunt. vamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Quisque velit nisi, pretium ut lacinia in.</p>
              <div class="testimonial__ratings"> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star_alt"></em> <span><em>4.9</em> (14 Reviews)</span> </div>
              <img class="comma" src="assets/images/testimonial/coma.png" alt="image"> </div>
          </div>
          <div class="single-client">
            <div class="client-bottom"> <span class="client-author"><img src="assets/images/testimonial/testimonial.png" alt="Testimonials"> </span> </div>
            <div class="client-content"> <span class="client-title">Justin Case <em> Student</em></span>
              <p>Nulla porttitor accumsan tincidunt. vamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Quisque velit nisi, pretium ut lacinia in.</p>
              <div class="testimonial__ratings"> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star_alt"></em> <span><em>4.9</em> (14 Reviews)</span> </div>
              <img class="comma" src="assets/images/testimonial/coma.png" alt="image"> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--================= Clients Section End Here =================--> 
  
  <!--================= Blog Section Start Here =================-->
  <div class="react-blog__area blog__area pt---90 pb---120">
    <div class="container blog__width">
      <div class="react__title__section text-center">
        <h2 class="react__tittle"> News and Blogs </h2>
      </div>
      <div class="row">
        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
          <div class="blog__card mb-50">
            <div class="blog__thumb w-img p-relative"> <a class="blog__thumb--image" href="blog-details.html"> <img src="assets/images/blog/1.jpg" alt="This the first card image"> </a> <em class="b_date">April 12</em> </div>
            <div class="blog__card--content">
              <div class="blog__card--content-area mb-25">
                <h3 class="blog__card--title"> <a href="blog-details.html">Announcing Espresso as Title Sponsor at the Delhi Carnival high energy Trader</a></h3>
              </div>
              <div class="blog__card--icon ">
                <div class="blog__card--icon-1"> We are thrilled to announce another partnership with the highly </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
          <div class="blog__card mb-50">
            <div class="blog__thumb w-img p-relative"> <a class="blog__thumb--image" href="blog-details.html"> <img src="assets/images/blog/2.jpg" alt="This the first card image"> </a> <em class="b_date">April 18</em> </div>
            <div class="blog__card--content">
              <div class="blog__card--content-area mb-25">
                <h3 class="blog__card--title"> <a href="blog-details.html">New Speaker Announcement - The Calming influence for a high energy Trader</a></h3>
              </div>
              <div class="blog__card--icon d-flex align-items-center">
                <div class="blog__card--icon-1"> We are thrilled to announce another partnership with the highly </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
          <div class="blog__card mb-50">
            <div class="blog__thumb w-img p-relative"> <a class="blog__thumb--image" href="blog-details.html"> <img src="assets/images/blog/3.jpg" alt="This the first card image"> </a> <em class="b_date">June 16</em> </div>
            <div class="blog__card--content">
              <div class="blog__card--content-area mb-25">
                <h3 class="blog__card--title"> <a href="blog-details.html">Crypto : How I doubled my money in 20 days without getting</a></h3>
              </div>
              <div class="blog__card--icon d-flex align-items-center">
                <div class="blog__card--icon-1"> We are thrilled to announce another partnership with the highly </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--================= Blog Section End Here =================--> 
  
</div>
</div>
<!--================= Wrapper End Here =================--> 
