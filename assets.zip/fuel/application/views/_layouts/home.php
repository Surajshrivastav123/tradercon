<?php $this->load->view('_blocks/header')?>
<?php $this->load->view('homebody')?>
 
	
<?php $this->load->view('_blocks/footer')?>
