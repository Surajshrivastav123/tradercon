<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="zxx">
<head>
<!--================= Meta tag =================-->
<meta charset="utf-8">
<title>CARNIVAL™ 2022</title>
<title>
		<!--__FUEL_MARKER__0-->ALGOMATICS TRADERS CONVENTION | CARNIVAL™ 2022
	</title>
  <meta name="keywords" content="<!--__FUEL_MARKER__1-->">
	<meta name="description" content="<!--__FUEL_MARKER__2-->From 23 to 25 Feb 2024 HYDERABAD">
<meta name="description" content="">
<!--================= Responsive Tag =================-->
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--================= Favicon =================-->
<link rel="apple-touch-icon" href="/carnival/assets/images/fav.png">
<link rel="shortcut icon" type="image/x-icon" href="/carnival/assets/images/fav.png">
<!--================= Bootstrap V5 css =================-->
<link href="/carnival/assets/css/bootstrap.min.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/menus.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/animate.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/owl.carousel.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/elegant-icon.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/magnific-popup.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/animations.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/style.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/custom-spacing.css?c=-62169955622" media="all" rel="stylesheet"/>
	<link href="/carnival/assets/css/responsive.css?c=-62169955622" media="all" rel="stylesheet"/>
	 
 
 
</head>
<body>
<!--================= Preloader Section Start Here =================-->
<div id="react__preloader">
  <div id="react__circle_loader"></div>
  <div class="react__loader_logo"><img src="/carnival/assets/images/preload.png" alt="Preload"></div>
</div>
<!--================= Preloader Section End Here =================--> 

<!--================= Header Section Start Here =================-->
<header id="react-header" class="react-header react-header-two">
  <div class="menu-part">
    <div class="container"> 
      <!--================= Menu Start Here =================-->
      <div class="react-main-menu">
        <nav> 
          <!--================= Menu Toggle btn =================-->
          <div class="menu-toggle">
            <div class="logo"><a href="http://berhampore.in/carnival/" class="logo-text"> <img src="/carnival/assets/images/logo2.png" alt="logo"> </a></div>
            <button type="button" id="menu-btn"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          </div>
          <!--================= Menu Structure =================-->
          <div class="react-inner-menus">
          
<ul style="" id="backmenu" class="react-menus react-sub-shadow">
	<li class="first"><a href="http://berhampore.in/carnival/about">About</a></li>
	<li><a href="http://berhampore.in/carnival/speakers">Speakers</a></li>
	<li><a href="http://berhampore.in/carnival/sponsors">Sponsors</a></li>
	<li><a href="http://berhampore.in/carnival/advisors">Mentors</a></li>
	<li><a href="http://berhampore.in/carnival/venue">Venue</a></li>
	<li><a href="http://berhampore.in/carnival/agenda">Agenda</a></li>
	<li class="last"><a href="http://berhampore.in/carnival/registration/0">Registration</a></li>
</ul>
            <ul id="backmenu" class="react-menus react-sub-shadow">
              <li> <a href="http://berhampore.in/carnival/Login">Login</a></li>
            </ul> 
            <div class="searchbar-part">
              <div class="react-logins"> <a href="#"> Buy Ticket Now
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
                </a> </div>
            </div>
          </div>
        </nav>
      </div>
      <!--=================  Menu End Here  =================--> 
    </div>
  </div>
</header>
<!--================= Header Section End Here =================--> 
 <!--================= Wrapper Start Here =================-->
<div class="react-wrapper">
  <div class="react-wrapper-inner"> 
    
    <!--================= Slider Section Start Here =================-->
    <style>
      .banner { 
      background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('/carnival/assets/images/banner/ourstory81.png');
      }
</style>
    <div class="react-slider-part">
      <section class="banner">
        <div class="banner-inner">
          <h1>ALGOMATICS TRADERS CONVENTION<br>
          From 23 to 25 Feb 2024 HYDERABAD</h1>
          <h4>EVENT WILL START IN</h4>
          <div id="normal-countdown" data-date="2022/02/02"></div>
          <a href="http://berhampore.in/carnival/prices" class="buybtn"> Buy Ticket Now
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right">
            <line x1="5" y1="12" x2="19" y2="12"></line>
            <polyline points="12 5 19 12 12 19"></polyline>
          </svg>
          </a> </div>
      </section>
    </div>
    <!--================= Slider Section End Here =================--> 
    
    <!--=================  About Section Start Here ================= -->
    <div class="about__area about__area_one p-relative pt---100 pb---70">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="about__content">
            <h2 class="about__title">Welcome to <br>
                <em>TRADERS CONVENTION</em></h2>
              <p class="about__paragraph">It all began on a cold winter morning on 26th October 2012 at Bangalore. History was made with the successful launch of the very first Edition of Traders Carnival.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>
              <p> With this step, we single-handedly pioneered the residential conference format for stock trading enthusiasts in the Indian markets. <br>
                10 years and 17 events later, we’ve only gone from strength to strength. Traders Carnival is now an established, nationally renowned brand with a flawless track record and instant name recognition amongst the trading community. The concept has stood the test of time and consistently delivered world-class content through a constellation of star speakers.</p>       
              </div>

          </div>
        </div>
      </div>
    </div>
    <!--================= About Section End Here ================= --> 
    
    <!--================= Upcoming Event Section Start Here =================-->
    <div class="react-upcoming__event blog__area pb---100">
      <div class="container">
        <div class="react__title__section text-center">
          <h5>Listen to the </h5>
          <h2 class="react__tittle">Event Speakers</h2>
        </div>
        <div class="instructors___page">
          <div class="row">
                      <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/xFHyJsFP_400x400.jpg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Vishal mehta</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/3"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Vishal mehta</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/jegan.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Jegan</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/2"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Jegan</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Manu_Bhatia.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Manu Bhatia</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/4"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Manu Bhatia</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/kiruba.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Kirubakaran</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/1"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Kirubakaran</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Jay.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Jay</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/7"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Jay</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Paff.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Praful Kulkarni</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/8"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Praful Kulkarni</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/df1972f4-40a1-4c47-aa46-e0d0664084eb.jpeg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Krish</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/19"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Krish</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Saket.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Saketh Rama Krishna</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/15"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Saketh Rama Krishna</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Kapil_Dhama.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Kapil Dhama</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/14"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Kapil Dhama</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/1516349732093.jpeg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Vivek Mashrani</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/16"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Vivek Mashrani</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/Harsha-portrait.png" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Harsha Vardhan</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/17"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Harsha Vardhan</a></h4>
                </div>
              </div>
            </div>
           
                        <div class="col-lg-3"> 
              <div class="instructor__content">
                <div class="instructor__image"> <img src="/carnival/assets/images/thumb.jpeg" alt="course instructor">
                  <div class="content__hover">
                    <ul>
                      <li>
                        <h5 class="white-color">Saddam (Saddy)</h5>
                      </li>
                    </ul>
                    <p class="iconsty"><a href="http://berhampore.in/carnival/profile/18"> <i class="arrow_carrot-right"></i> </a></p>
                  </div>
                </div>
                <div class="bottom-content">
                  <h4><a href="#">Saddam (Saddy)</a></h4>
                </div>
              </div>
            </div>
           
                      </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--================= Upcoming Event Section End Here =================--> 
  
  <!--=================  Pricing Start Here  =================-->
  <div class="pricing-section home-five pt---120">
    <div class="pricing-section-header-bg"></div>
    <div class="container">
      <div class="section-title-area home-five text-center">
        <div class="section-pretitle">I’M OFFER 3 UNIQUE PRICING PLANS</div>
        <div class="section-title">Pricing & Offerings Plan </div>
      </div>
      <div class="row justify-content-center">
              <div class="col-xl-4 col-md-4">
          <div class="price-card">
            <div class="price-plan">
              <div class="contents shape1 circle1">
                <div class="plan-type">2 Nights 3 Days Conference + Live Monthly Expiry Day Trading</div>
                <div class="price shapeTwo shapethree">3 Days - Double Occupancy</div>
              </div>
            </div>
            <div class="price-details">
                          <div class="item"> <i class="icon_check_alt2"></i>Conference + Live Expiry Day Trading </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Accommodation for 2 nights and 3 days at The Golkonda Resort, Hyd on DOUBLE OCCUPANCY from 9 to 11 Feb 2024</div>
                            <div class="item"> <i class="icon_check_alt2"></i>Access to all strategy and networking sessions during the 3 day event. </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Access to Expiry Day Trading - LIVE! </div>
                            <div class="item"> <i class="icon_check_alt2"></i>All meals during the conference, Coffee, Tea, Snacks, beverages </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Complimentary Internet access during the Conference. Internet connectivity of two devices per person is available. </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Complimentary access to indoor and out door activities, Club House and Pool </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Price : 2000</div>
                             
              <button class="price-btn">
              <a href="http://berhampore.in/carnival/registration/1">BOOK NOW</a>
              </button>
            </div>
          </div>
        </div>
                <div class="col-xl-4 col-md-4">
          <div class="price-card">
            <div class="price-plan">
              <div class="contents shape1 circle1">
                <div class="plan-type">2 Nights 3 Days Conference + Live Monthly Expiry Day Trading</div>
                <div class="price shapeTwo shapethree">Without Accommodation</div>
              </div>
            </div>
            <div class="price-details">
                          <div class="item"> <i class="icon_check_alt2"></i>Conference + Live Expiry Day Trading </div>
                            <div class="item"> <i class="icon_check_alt2"></i>No Accommodation </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Access to all strategy and networking sessions during the 3 day event. </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Access to Expiry Day Trading - LIVE!</div>
                            <div class="item"> <i class="icon_check_alt2"></i>All meals during the conference, Coffee, Tea, Snacks, beverages </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Complimentary Internet access during the Conference. Internet connectivity of two devices per person is available. </div>
                            <div class="item"> <i class="icon_check_alt2"></i>Price : 20000</div>
                             
              <button class="price-btn">
              <a href="http://berhampore.in/carnival/registration/2">BOOK NOW</a>
              </button>
            </div>
          </div>
        </div>
              </div>
    </div>
  </div>
  <!--=================  Pricing End Here  =================--> 
  
  <!--================= Clients Section Start Here =================-->
   <!-- <div class="react-clients react-clientso pt---120 pb---120 mt---102">
    <div class="container">
      <div class="react__title__section text-center">
        <h6 class="react__subtitle">Graat Words About carnival.</h6>
        <h2 class="react__tittle"> What our clients say about </h2>
      </div>
      <div class="container">
        <div class="client-slider owl-carousel">
          <div class="single-client">
            <div class="client-bottom"> <span class="client-author"><img src="assets/images/testimonial/testimonial.png" alt="Testimonials"> </span> </div>
            <div class="client-content"> <span class="client-title">Justin Case <em> Student</em></span>
              <p>Nulla porttitor accumsan tincidunt. vamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Quisque velit nisi, pretium ut lacinia in.</p>
              <div class="testimonial__ratings"> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star_alt"></em> <span><em>4.9</em> (14 Reviews)</span> </div>
              <img class="comma" src="assets/images/testimonial/coma.png" alt="image"> </div>
          </div>
          <div class="single-client">
            <div class="client-bottom"> <span class="client-author"><img src="assets/images/testimonial/testimonial.png" alt="Testimonials"> </span> </div>
            <div class="client-content"> <span class="client-title">Justin Case <em> Student</em></span>
              <p>Nulla porttitor accumsan tincidunt. vamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Quisque velit nisi, pretium ut lacinia in.</p>
              <div class="testimonial__ratings"> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star"></em> <em class="icon_star_alt"></em> <span><em>4.9</em> (14 Reviews)</span> </div>
              <img class="comma" src="assets/images/testimonial/coma.png" alt="image"> </div>
          </div>
        </div>
      </div>
    </div>
  </div>-->
  <!--================= Clients Section End Here =================--> 
  
  <!--================= Blog Section Start Here =================-->
  <div class="react-blog__area blog__area pt---90 pb---120">
    <div class="container blog__width">
      <div class="react__title__section text-center">
        <h2 class="react__tittle"> News and Blogs </h2>
      </div>
      <div class="row">
              
      </div>
    </div>
  </div>
  <!--================= Blog Section End Here =================--> 
  
</div>
</div>
<!--================= Wrapper End Here =================--> 
 
	
<!--================= Footer Section Start Here =================-->
<footer id="react-footer" class="react-footer react-footer-two pt---100 mt---100">
  <div class="footer-top">
	  
	  <div class="container">
                    <div class="footer-top-cta">
                        <div class="row">
                            <div class="col-lg-8">
                                <h3>Do you wish to associate with<br>Traders Carnival as a Sponsor?</h3>
                            </div>
                            <div class="col-lg-4 text-right">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal"> Go To FAQ <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
                            </div>
                        </div>
                    </div>
                </div> 
	  
	  
    <div class="container">
      <div class="row">
        <div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-1">
            <div class="footer-logo white"> <a href="index.html" class="logo-text"> <img src="assets/images/footer-logo.png" alt="logo"></a> </div>
            <h5 class="footer-subtitle">There are course and event custom <br>
              post types so you can easily create and<br>
              manage course, events.</h5>
            <ul class="footer-address">
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <a href="tel:+(402)76244183"> +(402) 762 441 83 </a></li>
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mail">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                <a href="mailto:info@yourdmain.com"> info@todaycarnival.com </a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-2">
            <h3 class="footer-title">About Us</h3>
            <div class="footer-menu">
            
<ul style="" id="usefullinks" class="footer-menu">
	<li class="first"><a href="http://berhampore.in/carnival/about">About</a></li>
	<li><a href="http://berhampore.in/carnival/agenda">Agenda</a></li>
	<li><a href="http://berhampore.in/carnival/prices">Prices</a></li>
	<li><a href="http://berhampore.in/carnival/speakers">Speakers</a></li>
	<li><a href="http://berhampore.in/carnival/sponsors">Sponsors</a></li>
	<li class="last"><a href="http://berhampore.in/carnival/venue">Venue</a></li>
</ul>
            </div>
          </div>
        </div>
        <div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-3">
            <h3 class="footer-title">Useful Links</h3>
            <div class="footer-menu">
            
<ul style="" id="usefullinks" class="footer-menu">
	<li class="first last">Mentors</li>
</ul>
             <!-- <ul>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="registration.html">Registration</a></li>
                <li><a href="Terms-Conditions.html">Terms & Conditions</a></li>
                <li><a href="privacy-policy.html">Privacy Policy</a></li>
                <li><a href="refund-policy.html">Refund Policy</a></li>
                <li><a href="blog.html.html">News & Blog</a></li>
                <li><a href="faq.html">FAQ</a></li>
              </ul>-->
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="footer-widget footer-widget-4">
            <h3 class="footer-title">Newsletter</h3>
            <div class="footer3__form">
              <p>Get the latest todaycarnival news <br>
                delivered to you inbox</p>
              <form action="#">
                <input type="email" placeholder="Enter your email">
                <button class="footer3__form-1"> <i class="arrow_right"></i> </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="react-copy-left">© 2022 <a href="#">todaycarnival.</a> All Rights Reserved</div>
      <div class="react-copy-right">
        <ul class="social-links">
          <li class="follow">Follow us</li>
          <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_linkedin"></span></a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!--================= Footer Section End Here =================--> 
	
	
	
<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Traders Carnival as a Sponsor ?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
		  
		  
		<div class="form-floating mb-3">
  <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Email address</label>
</div>
<div class="form-floating">
  <input type="password" class="form-control" id="floatingPhonenumber" placeholder="phonenumber">
  <label for="floatingPassword">Phone Number</label>
</div>  
		  
		  
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>	
	
	

<!--================= Scroll to Top Start =================-->
<div id="backscrollUp" class="home"> <span aria-hidden="true" class="arrow_carrot-up"></span> </div>
<!--================= Scroll to Top End =================--> 
<script src="/carnival/assets/js/jquery.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/modernizr-2.8.3.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/bootstrap.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/owl.carousel.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/jquery.magnific-popup.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/jquery.counterup.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/waypoints.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/menus.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/plugins.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/main.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/jquery.countdown.min.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<script src="/carnival/assets/js/scripts.js?c=-62169955622" type="text/javascript" charset="utf-8"></script>
	<!--================= Jquery latest version =================--> 
 
 
</body>
</html><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>