<?php 

$config['modules']['events_master'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_sponsors'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_speakers'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_images'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_videos'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_pricing_plans'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);

$config['modules']['event_registration'] = array(
	'preview_path' => '', // put in the preview path on the site e.g products/{slug}
	'model_location' => 'events', // put in the advanced module name here
);
