<?php 
$lang['module_events'] = 'Events';