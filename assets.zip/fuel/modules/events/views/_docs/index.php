<h1>Events Module Documentation</h1>
<p>This Events module documentation is for version <?=EVENTS_VERSION?>.</p>

<?=generate_config_info()?>

<?=generate_toc()?>