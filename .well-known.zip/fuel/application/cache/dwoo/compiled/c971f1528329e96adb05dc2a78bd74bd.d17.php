<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="zxx">
<head>
<!--================= Meta tag =================-->
<meta charset="utf-8">
<title>Tradersconvention - 2023</title>
<title>
		<!--__FUEL_MARKER__0-->About : Home | Tradersconvention - 2023
	</title>
  <meta name="keywords" content="<!--__FUEL_MARKER__1-->">
	<meta name="description" content="<!--__FUEL_MARKER__2-->">
<meta name="description" content="">
<!--================= Responsive Tag =================-->
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--================= Favicon =================-->
<link rel="apple-touch-icon" href="/assets/images/fav.png">
<link rel="shortcut icon" type="image/x-icon" href="/assets/images/fav.png">
<!--================= Bootstrap V5 css =================-->
<link href="/assets/css/bootstrap.min.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/menus.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/animate.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/owl.carousel.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/elegant-icon.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/magnific-popup.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/animations.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/style.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/custom-spacing.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/responsive.css?c=-62170005208" media="all" rel="stylesheet"/>
	 
 
 
</head>
<body>
<!--================= Preloader Section Start Here =================-->
<div id="react__preloader">
  <div id="react__circle_loader"></div>
  <div class="react__loader_logo"><img src="/assets/images/preload.png" alt="Preload"></div>
</div>
<!--================= Preloader Section End Here =================--> 

<!--================= Header Section Start Here =================-->
<header id="react-header" class="react-header react-header-two">
  <div class="menu-part">
    <div class="container"> 
      <!--================= Menu Start Here =================-->
      <div class="react-main-menu">
        <nav> 
          <!--================= Menu Toggle btn =================-->
          <div class="menu-toggle">
            <div class="logo"><a href="https://tradersconvention.com/" class="logo-text"> <img src="/assets/images/logo2.png" alt="logo"> </a></div>
            <button type="button" id="menu-btn"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          </div>
          <!--================= Menu Structure =================-->
          <div class="react-inner-menus">
          
<ul style="" id="backmenu" class="react-menus react-sub-shadow">
	<li class="first"><a href="https://tradersconvention.com/about">About</a></li>
	<li><a href="https://tradersconvention.com/speakers">Speakers</a></li>
	<li><a href="https://tradersconvention.com/advisors">Mentors</a></li>
	<li><a href="https://tradersconvention.com/sponsors">Sponsors</a></li>
	<li><a href="https://tradersconvention.com/venue">Venue</a></li>
	<li><a href="https://tradersconvention.com/agenda">Agenda</a></li>
	<li class="last"><a href="https://tradersconvention.com/registration/0">Registration</a></li>
</ul>
            <ul id="backmenu" class="react-menus react-sub-shadow">
              <li> <!--<a href="https://tradersconvention.com/Login">Login</a>--></li>
            </ul> 
            <div class="searchbar-part">
              <div class="react-logins"> <a href="#"> Buy Ticket Now
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
                </a> </div>
            </div>
          </div>
        </nav>
      </div>
      <!--=================  Menu End Here  =================--> 
    </div>
  </div>
</header>
<!--================= Header Section End Here =================--> 
	
<div class="react-wrapper">
            <div class="react-wrapper-inner">
		<!--__FUEL_MARKER__3--><div class="breadcrumbs-wrap">
                        <img class="desktop" src="assets/images/agenda/modified_(2).jpg" alt="Breadcrumbs">
                        <img class="mobile" src="assets/images/breadcrumbs/1.jpg" alt="Breadcrumbs">
                        <div class="breadcrumbs-inner">
                            <div class="container">
                                <div class="breadcrumbs-text">
                                    <h1 class="breadcrumbs-title">About</h1>
                                    <div class="back-nav">
                                        <ul>
                                            <li><a href="index.html">Home</a></li>
                                            <li>Profile</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                
                
                

               <div class="about__area about__area_one p-relative pt---100 pb---120">
                    <div class="container">                        
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="about__image">
                                    <img src="assets/images/about/ab.png" alt="About">
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="about__content">
                                    <h2 class="about__title">Welcome to <br> <em> TRADERS CONVENTION</em></h2>
									
                                    <p>Dear Participants/Attendees,

It is with great pleasure and excitement that we welcome you to TRADERS CONVETION! As Traders Convention team, we are thrilled to have you join us for what promises to be an unforgettable and enriching experience.

Traders convention is not just an event; it's a celebration of [mention the purpose or theme of the event]. Over the next 3 days from Feb 23rd to 25th, we have curated a series of engaging activities, insightful sessions, and networking opportunities that aim to [highlight the key objectives or goals of the event]. Whether you are here to [mention specific goals, such as learning, networking, or simply enjoying], we have something special in store for each and every one of you.

Our team has worked diligently to ensure that Traders Convention exceeds your expectations. From inspiring keynote speakers to hands-on workshops, we've designed a program that caters to a diverse range of interests and preferences. We encourage you to immerse yourself fully in the experience, connect with fellow participants, and make the most out of this incredible opportunity. </p>
									
								
                                </div>
                            </div>
                        </div>
						
						<hr>
						
						
						<div class="row">
                           
                            <div class="col-lg-7">
                                <div class="about__content">
                                    <h2 class="about__title">Welcome to <br> <em>TRADERS CONVENTION</em></h2>
									
                                    <p>Hello, traders and enthusiasts! Exciting news from our end,

I am Vamsi Krishna, usually called Krish! Former IT admin turned full-time Trader and Investor based in the vibrant city of Hyderabad. <br>

we thrilled to announce the launch of the Traders Convention this year, a remarkable event that brings together like-minded traders and investors under one roof. Over the past 8 years, we have been actively involved in organizing meetups across various cities, fostering a community of passionate individuals dedicated to the art of trading. <br>

The Traders Convention is not just any event; it's an annual residential conference that promises to be an enriching experience for all attendees. we invited some of the most successful traders and renowned names in the industry to share their insights and experiences. Expect to hear from those who trade for a living and have made a significant impact in the trading world. <br>

This is an incredible opportunity for networking, learning, and gaining valuable insights into the world of trading and investing. Whether you're a trader or investor, the Traders Convention in Hyderabad is where you want to be! <br>

Stay tuned for more updates, and don't miss the chance to be a part of this dynamic event. Let's make the Traders Convention a grand success! </p>
									
								
									
                                </div>
                            </div>
							 <div class="col-lg-5">
                                <div class="about__image">
                                    <img src="assets/images/about/ab.png" alt="About">
                                    <img class="react__shape__ab" src="assets/images/about/badge.png" alt="Shape Image">
                                </div>
                            </div>
                        </div>
						
						
						
						
						
						
                    </div>
                </div>		</div>
        </div>
	
<!--================= Footer Section Start Here =================-->
<footer id="react-footer" class="react-footer react-footer-two pt---100 mt---100">
  <div class="footer-top">
	  
	  <div class="container">
                    <div class="footer-top-cta">
                        <div class="row">
                            <div class="col-lg-8">
                                <h3>Do you wish to associate with<br>Traders Convention as a Sponsor?</h3>
                            </div>
                            <div class="col-lg-4 text-right">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal"> Go To FAQ <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
                            </div>
                        </div>
                    </div>
                </div> 
	  
	  
    <div class="container">
      <div class="row">
		  
        <!--<div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-1">
            <div class="footer-logo white"> <a href="index.html" class="logo-text"> <img src="assets/images/footer-logo.png" alt="logo"></a> </div>
            <h5 class="footer-subtitle">There are course and event custom <br>
              post types so you can easily create and<br>
              manage course, events.</h5>
            <ul class="footer-address">
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <a href="tel:+(402)76244183"> +(402) 762 441 83 </a></li>
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mail">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                <a href="mailto:info@yourdmain.com"> info@todaycarnival.com </a></li>
            </ul>
          </div>
        </div>-->
		  
        <div class="col-lg-12">
          <div class="footer-widget text-center">
            <!--<h3 class="footer-title">About Us</h3>-->
            <div class="footer-menu">
            
<ul style="" id="usefullinks" class="footer-menu">
	<li class="first"><a href="https://tradersconvention.com/about">About</a></li>
	<li><a href="https://tradersconvention.com/agenda">Agenda</a></li>
	<li><a href="https://tradersconvention.com/prices">Prices</a></li>
	<li><a href="https://tradersconvention.com/speakers">Speakers</a></li>
	<li><a href="https://tradersconvention.com/sponsors">Sponsors</a></li>
	<li><a href="https://tradersconvention.com/venue">Venue</a></li>
	<li><a href="https://tradersconvention.com/Privacy-Policy">Privacy Policy</a></li>
	<li><a href="https://tradersconvention.com/terms-conditions">Terms & Conditions</a></li>
	<li class="last"><a href="https://tradersconvention.com/Refund-Policy">Refund Policy</a></li>
</ul>
            </div>
          </div>
        </div>
		  
       <!-- <div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-3">
            <h3 class="footer-title">Useful Links</h3>
            <div class="footer-menu">
                          <ul>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="registration.html">Registration</a></li>
                <li><a href="Terms-Conditions.html">Terms & Conditions</a></li>
                <li><a href="privacy-policy.html">Privacy Policy</a></li>
                <li><a href="refund-policy.html">Refund Policy</a></li>
                <li><a href="blog.html.html">News & Blog</a></li>
                <li><a href="faq.html">FAQ</a></li>
              </ul>
            </div>
          </div>
        </div>-->
		  
       <!-- <div class="col-lg-3">
          <div class="footer-widget footer-widget-4">
            <h3 class="footer-title">Newsletter</h3>
            <div class="footer3__form">
              <p>Get the latest todaycarnival news <br>
                delivered to you inbox</p>
              <form action="#">
                <input type="email" placeholder="Enter your email">
                <button class="footer3__form-1"> <i class="arrow_right"></i> </button>
              </form>
            </div>
          </div>
        </div>-->
		  
		  
		  
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="react-copy-left">© 2023 <a href="#">tradersconvention.com</a> All Rights Reserved</div>
      <div class="react-copy-right">
        <ul class="social-links">
          <li class="follow">Follow us</li>
          <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_linkedin"></span></a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!--================= Footer Section End Here =================--> 
	
	
	
<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Traders Carnival as a Sponsor ?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
		  
		  
		<div class="form-floating mb-3">
  <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Email address</label>
</div>
<div class="form-floating">
  <input type="password" class="form-control" id="floatingPhonenumber" placeholder="phonenumber">
  <label for="floatingPassword">Phone Number</label>
</div>  
		  
		  
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>	
	
	

<!--================= Scroll to Top Start =================-->
<div id="backscrollUp" class="home"> <span aria-hidden="true" class="arrow_carrot-up"></span> </div>
<!--================= Scroll to Top End =================--> 
<script src="/assets/js/jquery.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/modernizr-2.8.3.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/bootstrap.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/owl.carousel.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.magnific-popup.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.counterup.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/waypoints.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/menus.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/plugins.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/main.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.countdown.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/scripts.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<!--================= Jquery latest version =================--> 
 
 
</body>
</html><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>