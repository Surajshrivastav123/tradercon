<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><!DOCTYPE html>
<html lang="zxx">
<head>
<!--================= Meta tag =================-->
<meta charset="utf-8">
<title>Tradersconvention - 2023</title>
<title>
		<!--__FUEL_MARKER__0-->Home | Tradersconvention - 2023
	</title>
  <meta name="keywords" content="<!--__FUEL_MARKER__1-->">
	<meta name="description" content="<!--__FUEL_MARKER__2-->">
<meta name="description" content="">
<!--================= Responsive Tag =================-->
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--================= Favicon =================-->
<link rel="apple-touch-icon" href="/assets/images/fav.png">
<link rel="shortcut icon" type="image/x-icon" href="/assets/images/fav.png">
<!--================= Bootstrap V5 css =================-->
<link href="/assets/css/bootstrap.min.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/menus.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/animate.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/owl.carousel.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/elegant-icon.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/magnific-popup.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/animations.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/style.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/custom-spacing.css?c=-62170005208" media="all" rel="stylesheet"/>
	<link href="/assets/css/responsive.css?c=-62170005208" media="all" rel="stylesheet"/>
	 
 
 
</head>
<body>
<!--================= Preloader Section Start Here =================-->
<div id="react__preloader">
  <div id="react__circle_loader"></div>
  <div class="react__loader_logo"><img src="/assets/images/preload.png" alt="Preload"></div>
</div>
<!--================= Preloader Section End Here =================--> 

<!--================= Header Section Start Here =================-->
<header id="react-header" class="react-header react-header-two">
  <div class="menu-part">
    <div class="container"> 
      <!--================= Menu Start Here =================-->
      <div class="react-main-menu">
        <nav> 
          <!--================= Menu Toggle btn =================-->
          <div class="menu-toggle">
            <div class="logo"><a href="https://tradersconvention.com/" class="logo-text"> <img src="/assets/images/logo2.png" alt="logo"> </a></div>
            <button type="button" id="menu-btn"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
          </div>
          <!--================= Menu Structure =================-->
          <div class="react-inner-menus">
          
<ul style="" id="backmenu" class="react-menus react-sub-shadow">
	<li class="first"><a href="https://tradersconvention.com/about">About</a></li>
	<li><a href="https://tradersconvention.com/speakers">Speakers</a></li>
	<li><a href="https://tradersconvention.com/advisors">Mentors</a></li>
	<li><a href="https://tradersconvention.com/sponsors">Sponsors</a></li>
	<li><a href="https://tradersconvention.com/venue">Venue</a></li>
	<li><a href="https://tradersconvention.com/agenda">Agenda</a></li>
	<li class="last"><a href="https://tradersconvention.com/registration/0">Registration</a></li>
</ul>
            <ul id="backmenu" class="react-menus react-sub-shadow">
              <li> <!--<a href="https://tradersconvention.com/Login">Login</a>--></li>
            </ul> 
            <div class="searchbar-part">
              <div class="react-logins"> <a href="#"> Buy Ticket Now
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
                </a> </div>
            </div>
          </div>
        </nav>
      </div>
      <!--=================  Menu End Here  =================--> 
    </div>
  </div>
</header>
<!--================= Header Section End Here =================--> 
	
	<section id="main_inner">
		<!--__FUEL_MARKER__3--><div class="container mt---100 mb----100">

<h3>Terms and Conditions</h3>
Welcome to tradersconvention.com!

These terms and conditions outline the rules and regulations for the use of Traders Convention’s Website, located at https://www.tradersconvention.com.

By accessing this website we assume you accept these terms and conditions. Do not continue to use tradersconvention.com if you do not agree to take all of the terms and conditions stated on this page.

The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: “Client”, “You” and “Your” refers to you, the person log on this website and compliant to the Company’s terms and conditions. “The Company”, “Ourselves”, “We”, “Our” and “Us”, refers to our Company. “Party”, “Parties”, or “Us”, refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of provision of the Company’s stated services, in accordance with and subject to, prevailing law of Netherlands. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they, are taken as interchangeable and therefore as referring to same.<br><br>

<h3>Cookies</h3>

We employ the use of cookies. By accessing traderscarnival.com, you agreed to use cookies in agreement with the Traders Carnival’s Privacy Policy.

Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.<br><br>

<h3>License</h3>
Unless otherwise stated, Traders Convention and/or its licensors own the intellectual property rights for all material on tradersconvention.com. All intellectual property rights are reserved. You may access this from tradersconvention.com for your own personal use subjected to restrictions set in these terms and conditions.<br><br>

You must not:

<ul>
<li>Republish material from tradersconvention.com</li>
<li>Sell, rent or sub-license material from tradersconvention.com</li>
<li>Reproduce, duplicate or copy material from tradersconvention.com</li>
<li>Redistribute content from tradersconvention.com</li>
<li>This Agreement shall begin on the date hereof.</li> 
</ul>




</div>	</section>
	
<!--================= Footer Section Start Here =================-->
<footer id="react-footer" class="react-footer react-footer-two pt---100 mt---100">
  <div class="footer-top">
	  
	  <div class="container">
                    <div class="footer-top-cta">
                        <div class="row">
                            <div class="col-lg-8">
                                <h3>Do you wish to associate with<br>Traders Convention as a Sponsor?</h3>
                            </div>
                            <div class="col-lg-4 text-right">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#loginModal"> Go To FAQ <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></a>
                            </div>
                        </div>
                    </div>
                </div> 
	  
	  
    <div class="container">
      <div class="row">
		  
        <!--<div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-1">
            <div class="footer-logo white"> <a href="index.html" class="logo-text"> <img src="assets/images/footer-logo.png" alt="logo"></a> </div>
            <h5 class="footer-subtitle">There are course and event custom <br>
              post types so you can easily create and<br>
              manage course, events.</h5>
            <ul class="footer-address">
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-phone">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <a href="tel:+(402)76244183"> +(402) 762 441 83 </a></li>
              <li>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mail">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                <a href="mailto:info@yourdmain.com"> info@todaycarnival.com </a></li>
            </ul>
          </div>
        </div>-->
		  
        <div class="col-lg-12">
          <div class="footer-widget text-center">
            <!--<h3 class="footer-title">About Us</h3>-->
            <div class="footer-menu">
            
<ul style="" id="usefullinks" class="footer-menu">
	<li class="first"><a href="https://tradersconvention.com/about">About</a></li>
	<li><a href="https://tradersconvention.com/agenda">Agenda</a></li>
	<li><a href="https://tradersconvention.com/prices">Prices</a></li>
	<li><a href="https://tradersconvention.com/speakers">Speakers</a></li>
	<li><a href="https://tradersconvention.com/sponsors">Sponsors</a></li>
	<li><a href="https://tradersconvention.com/venue">Venue</a></li>
	<li><a href="https://tradersconvention.com/Privacy-Policy">Privacy Policy</a></li>
	<li><a href="https://tradersconvention.com/terms-conditions">Terms & Conditions</a></li>
	<li class="last"><a href="https://tradersconvention.com/Refund-Policy">Refund Policy</a></li>
</ul>
            </div>
          </div>
        </div>
		  
       <!-- <div class="col-lg-3 md-mb-30">
          <div class="footer-widget footer-widget-3">
            <h3 class="footer-title">Useful Links</h3>
            <div class="footer-menu">
                          <ul>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="registration.html">Registration</a></li>
                <li><a href="Terms-Conditions.html">Terms & Conditions</a></li>
                <li><a href="privacy-policy.html">Privacy Policy</a></li>
                <li><a href="refund-policy.html">Refund Policy</a></li>
                <li><a href="blog.html.html">News & Blog</a></li>
                <li><a href="faq.html">FAQ</a></li>
              </ul>
            </div>
          </div>
        </div>-->
		  
       <!-- <div class="col-lg-3">
          <div class="footer-widget footer-widget-4">
            <h3 class="footer-title">Newsletter</h3>
            <div class="footer3__form">
              <p>Get the latest todaycarnival news <br>
                delivered to you inbox</p>
              <form action="#">
                <input type="email" placeholder="Enter your email">
                <button class="footer3__form-1"> <i class="arrow_right"></i> </button>
              </form>
            </div>
          </div>
        </div>-->
		  
		  
		  
      </div>
    </div>
  </div>
  <div class="copyright">
    <div class="container">
      <div class="react-copy-left">© 2023 <a href="#">tradersconvention.com</a> All Rights Reserved</div>
      <div class="react-copy-right">
        <ul class="social-links">
          <li class="follow">Follow us</li>
          <li><a href="#"><span aria-hidden="true" class="social_facebook"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_twitter"></span></a></li>
          <li><a href="#"><span aria-hidden="true" class="social_linkedin"></span></a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>
<!--================= Footer Section End Here =================--> 
	
	
	
<!-- Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Traders Carnival as a Sponsor ?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
		  
		  
		<div class="form-floating mb-3">
  <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
  <label for="floatingInput">Email address</label>
</div>
<div class="form-floating">
  <input type="password" class="form-control" id="floatingPhonenumber" placeholder="phonenumber">
  <label for="floatingPassword">Phone Number</label>
</div>  
		  
		  
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>	
	
	

<!--================= Scroll to Top Start =================-->
<div id="backscrollUp" class="home"> <span aria-hidden="true" class="arrow_carrot-up"></span> </div>
<!--================= Scroll to Top End =================--> 
<script src="/assets/js/jquery.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/modernizr-2.8.3.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/bootstrap.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/owl.carousel.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.magnific-popup.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.counterup.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/waypoints.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/menus.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/plugins.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/main.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/jquery.countdown.min.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<script src="/assets/js/scripts.js?c=-62170005208" type="text/javascript" charset="utf-8"></script>
	<!--================= Jquery latest version =================--> 
 
 
</body>
</html><?php  /* end template body */
return $this->buffer . ob_get_clean();
?>