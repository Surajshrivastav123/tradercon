<?php $this->load->view('_blocks/header')?>
	
<div class="react-wrapper">
            <div class="react-wrapper-inner">
		<?php echo fuel_var('body', 'This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.'); ?>
		</div>
        </div>
	
<?php $this->load->view('_blocks/footer')?>
