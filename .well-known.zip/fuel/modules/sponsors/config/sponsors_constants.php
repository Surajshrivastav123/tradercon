<?php 
define('SPONSORS_VERSION', '1.0');
define('SPONSORS_FOLDER', 'sponsors');
define('SPONSORS_PATH', MODULES_PATH.SPONSORS_FOLDER.'/');