<?php 
$route[FUEL_ROUTE.'sponsors_master'] = 'sponsors';
