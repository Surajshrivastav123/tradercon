<?php 
$lang['module_sponsors'] = 'Sponsors';