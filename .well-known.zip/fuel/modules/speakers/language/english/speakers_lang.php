<?php 
$lang['module_speakers'] = 'Speakers';