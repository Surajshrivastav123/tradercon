<?php 
define('SPEAKERS_VERSION', '1.0');
define('SPEAKERS_FOLDER', 'speakers');
define('SPEAKERS_PATH', MODULES_PATH.SPEAKERS_FOLDER.'/');