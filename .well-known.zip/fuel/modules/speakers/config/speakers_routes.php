<?php 
$route[FUEL_ROUTE.'speakers_master'] = 'speakers';
