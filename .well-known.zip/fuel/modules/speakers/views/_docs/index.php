<h1>Speakers Module Documentation</h1>
<p>This Speakers module documentation is for version <?=SPEAKERS_VERSION?>.</p>

<?=generate_config_info()?>

<?=generate_toc()?>